import React, { useState } from "react";
import {
  View, Text, TextInput, TouchableOpacity, Image,
  StyleSheet, ActivityIndicator, ScrollView, StatusBar, Keyboard
} from "react-native";

// Depois de publicar o backend no Render, substitua pela URL real,
// por exemplo: https://pokeapp-api-xxxx.onrender.com
const API_URL = "COLE_AQUI_A_URL_DO_RENDER";

export default function App() {
  const [busca, setBusca] = useState("");
  const [pokemon, setPokemon] = useState(null);
  const [carregando, setCarregando] = useState(false);
  const [erro, setErro] = useState("");

  async function pesquisar() {
    const termo = busca.trim().toLowerCase();
    if (!termo) {
      setErro("Digite o nome ou número de um Pokémon.");
      setPokemon(null);
      return;
    }
    if (API_URL.includes("COLE_AQUI")) {
      setErro("Configure primeiro a URL pública do backend no arquivo App.js.");
      return;
    }

    Keyboard.dismiss();
    setCarregando(true);
    setErro("");
    setPokemon(null);

    try {
      const resposta = await fetch(`${API_URL}/api/pokemon/${encodeURIComponent(termo)}`);
      const dados = await resposta.json();

      if (!resposta.ok) {
        throw new Error(dados.erro || "Não foi possível encontrar o Pokémon.");
      }
      setPokemon(dados);
    } catch (e) {
      setErro(e.message || "Erro de conexão com a API.");
    } finally {
      setCarregando(false);
    }
  }

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#D93636" />
      <View style={styles.header}>
        <View style={styles.logoRow}>
          <View style={styles.pokeball}>
            <View style={styles.pokeballLine} />
            <View style={styles.pokeballCenter} />
          </View>
          <Text style={styles.logo}>PokéApp</Text>
        </View>
        <Text style={styles.subtitle}>Descubra seu Pokémon favorito!</Text>
      </View>

      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <Text style={styles.heading}>Encontre um Pokémon</Text>
        <Text style={styles.description}>Pesquise pelo nome ou número da Pokédex.</Text>

        <View style={styles.searchRow}>
          <TextInput
            style={styles.input}
            value={busca}
            onChangeText={setBusca}
            placeholder="Ex.: pikachu ou 25"
            placeholderTextColor="#888"
            autoCapitalize="none"
            onSubmitEditing={pesquisar}
            returnKeyType="search"
          />
          <TouchableOpacity style={styles.searchButton} onPress={pesquisar} disabled={carregando}>
            <Text style={styles.searchButtonText}>Buscar</Text>
          </TouchableOpacity>
        </View>

        {carregando && (
          <View style={styles.message}>
            <ActivityIndicator size="large" color="#D93636" />
            <Text style={styles.messageText}>Procurando Pokémon...</Text>
          </View>
        )}

        {!!erro && !carregando && (
          <View style={styles.errorBox}><Text style={styles.errorText}>{erro}</Text></View>
        )}

        {pokemon && !carregando && (
          <View style={styles.card}>
            <Text style={styles.number}>Nº {String(pokemon.id).padStart(3, "0")}</Text>
            {pokemon.imagem ? (
              <Image source={{ uri: pokemon.imagem }} style={styles.pokemonImage} resizeMode="contain" />
            ) : (
              <View style={styles.noImage}><Text style={styles.noImageText}>Imagem indisponível</Text></View>
            )}
            <Text style={styles.name}>{pokemon.nome}</Text>
            <Text style={styles.sectionTitle}>TIPOS</Text>
            <View style={styles.types}>
              {pokemon.tipos.map((tipo) => (
                <View key={tipo} style={styles.typePill}>
                  <Text style={styles.typeText}>{tipo}</Text>
                </View>
              ))}
            </View>
            <View style={styles.stats}>
              <View style={styles.stat}>
                <Text style={styles.statValue}>{Number(pokemon.altura).toFixed(1)} m</Text>
                <Text style={styles.statLabel}>ALTURA</Text>
              </View>
              <View style={styles.statDivider} />
              <View style={styles.stat}>
                <Text style={styles.statValue}>{Number(pokemon.peso).toFixed(1)} kg</Text>
                <Text style={styles.statLabel}>PESO</Text>
              </View>
            </View>
          </View>
        )}

        {!pokemon && !erro && !carregando && (
          <View style={styles.welcome}>
            <Text style={styles.welcomeEmoji}>⚡</Text>
            <Text style={styles.welcomeTitle}>Pronto para explorar?</Text>
            <Text style={styles.welcomeText}>
              Digite o nome de um Pokémon, como Pikachu, ou seu número na Pokédex.
            </Text>
          </View>
        )}
        <Text style={styles.footer}>Informações consultadas pela API do PokéApp</Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#F4F5F8" },
  header: { backgroundColor: "#D93636", paddingTop: 48, paddingBottom: 25, paddingHorizontal: 22, borderBottomLeftRadius: 25, borderBottomRightRadius: 25 },
  logoRow: { flexDirection: "row", alignItems: "center", justifyContent: "center" },
  logo: { color: "#FFF", fontSize: 30, fontWeight: "900", marginLeft: 10 },
  pokeball: { width: 30, height: 30, borderRadius: 15, backgroundColor: "#FFF", borderWidth: 2, borderColor: "#222", overflow: "hidden", justifyContent: "center" },
  pokeballLine: { height: 3, backgroundColor: "#222", width: "100%" },
  pokeballCenter: { position: "absolute", alignSelf: "center", width: 10, height: 10, borderRadius: 5, backgroundColor: "#FFF", borderWidth: 2, borderColor: "#222" },
  subtitle: { color: "#FFE8E8", textAlign: "center", marginTop: 8, fontSize: 14 },
  content: { padding: 20, paddingBottom: 30 },
  heading: { fontSize: 23, fontWeight: "800", color: "#242633" },
  description: { color: "#737785", marginTop: 5, marginBottom: 18, fontSize: 14 },
  searchRow: { flexDirection: "row", gap: 9 },
  input: { flex: 1, backgroundColor: "#FFF", borderRadius: 12, paddingHorizontal: 14, height: 50, borderWidth: 1, borderColor: "#E1E3E9", fontSize: 15, color: "#222" },
  searchButton: { backgroundColor: "#252A3A", borderRadius: 12, paddingHorizontal: 17, justifyContent: "center", alignItems: "center" },
  searchButtonText: { color: "#FFF", fontWeight: "800" },
  message: { alignItems: "center", marginTop: 35, gap: 10 },
  messageText: { color: "#555B69", fontSize: 15 },
  errorBox: { backgroundColor: "#FDE8E8", borderColor: "#F5BABA", borderWidth: 1, borderRadius: 12, padding: 14, marginTop: 20 },
  errorText: { color: "#A51F1F", textAlign: "center", fontWeight: "600" },
  card: { backgroundColor: "#FFF", borderRadius: 22, marginTop: 23, padding: 20, alignItems: "center", elevation: 3, shadowColor: "#000", shadowOpacity: 0.08, shadowRadius: 10, shadowOffset: { width: 0, height: 4 } },
  number: { alignSelf: "flex-end", color: "#9297A4", fontWeight: "800", fontSize: 14 },
  pokemonImage: { width: 205, height: 205, marginTop: 3 },
  noImage: { width: 205, height: 205, justifyContent: "center" },
  noImageText: { color: "#888" },
  name: { color: "#252A3A", fontSize: 27, fontWeight: "900", textTransform: "capitalize" },
  sectionTitle: { color: "#9297A4", fontSize: 11, fontWeight: "900", marginTop: 19, letterSpacing: 1.5 },
  types: { flexDirection: "row", gap: 8, marginTop: 9 },
  typePill: { backgroundColor: "#E9EEF8", paddingVertical: 7, paddingHorizontal: 15, borderRadius: 20 },
  typeText: { color: "#39445B", fontWeight: "800", textTransform: "capitalize" },
  stats: { flexDirection: "row", width: "100%", justifyContent: "space-evenly", marginTop: 23, paddingTop: 17, borderTopWidth: 1, borderTopColor: "#ECEEF2" },
  stat: { alignItems: "center", flex: 1 },
  statValue: { fontSize: 19, color: "#252A3A", fontWeight: "900" },
  statLabel: { fontSize: 10, color: "#9297A4", fontWeight: "800", marginTop: 5, letterSpacing: 1 },
  statDivider: { width: 1, backgroundColor: "#ECEEF2" },
  welcome: { backgroundColor: "#FFF", borderRadius: 20, padding: 25, marginTop: 28, alignItems: "center" },
  welcomeEmoji: { fontSize: 42 },
  welcomeTitle: { color: "#252A3A", fontSize: 18, fontWeight: "800", marginTop: 8 },
  welcomeText: { color: "#777D8A", textAlign: "center", lineHeight: 21, marginTop: 8 },
  footer: { textAlign: "center", color: "#A0A4AE", fontSize: 11, marginTop: 25 }
});