const express = require("express");
const router = express.Router();
const buscarPokemon = require("../services/pokeapi");

router.get("/:nome", async (req, res) => {
  try {
    const pokemon = await buscarPokemon(req.params.nome);
    res.json(pokemon);
  } catch (erro) {
    if (erro.message === "POKEMON_NAO_ENCONTRADO") {
      return res.status(404).json({
        erro: "Pokémon não encontrado. Confira o nome ou número."
      });
    }

    console.error("Erro ao consultar Pokémon:", erro);
    res.status(502).json({
      erro: "Não foi possível consultar a PokéAPI. Tente novamente."
    });
  }
});

module.exports = router;