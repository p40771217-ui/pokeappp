const express = require("express");
const cors = require("cors");
const pokemonRoutes = require("./routes/pokemon");

const app = express();
const PORT = process.env.PORT || 10000;

app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
  res.json({
    projeto: "PokéApp",
    mensagem: "API funcionando!",
    status: "online"
  });
});

app.use("/api/pokemon", pokemonRoutes);

app.use((req, res) => {
  res.status(404).json({ erro: "Rota não encontrada." });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`PokéApp API executando na porta ${PORT}`);
});