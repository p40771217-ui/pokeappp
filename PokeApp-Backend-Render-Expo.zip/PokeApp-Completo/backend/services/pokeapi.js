async function buscarPokemon(nome) {
  const identificador = encodeURIComponent(
    String(nome).trim().toLowerCase()
  );

  const resposta = await fetch(
    `https://pokeapi.co/api/v2/pokemon/${identificador}`
  );

  if (resposta.status === 404) {
    throw new Error("POKEMON_NAO_ENCONTRADO");
  }

  if (!resposta.ok) {
    throw new Error("ERRO_NA_POKEAPI");
  }

  const dados = await resposta.json();

  return {
    id: dados.id,
    nome: dados.name,
    imagem:
      dados.sprites.other?.["official-artwork"]?.front_default ||
      dados.sprites.front_default,
    tipos: dados.types.map((item) => item.type.name),
    altura: dados.height / 10,
    peso: dados.weight / 10
  };
}

module.exports = buscarPokemon;